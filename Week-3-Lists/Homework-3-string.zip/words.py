# Alex Chen
# Prof Sun
# ET 574
# Words.py


sentence = input("Enter a sentence: ")
print(f"Number of words: {len(sentence.split())}")
